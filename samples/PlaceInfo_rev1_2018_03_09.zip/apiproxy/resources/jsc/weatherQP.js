var reqQP= context.getVariable('parameter.qp');
var newreqQP = "APPID=8d33c0ee070e86f7a8961a9ee10af071&zip="+reqQP;
context.setVariable("newrequest.queryparam",newreqQP);