var weatherResponse = context.getVariable('weatherInfoResponse');
var response_Object = JSON.parse(weatherResponse.content);
print(response_Object);
var new_Object = response_Object.main;
context.setVariable("newweatherInfoResponse",JSON.stringify(new_Object, null, 2));
//response.content = JSON.stringify(new_Object, null, 2);

